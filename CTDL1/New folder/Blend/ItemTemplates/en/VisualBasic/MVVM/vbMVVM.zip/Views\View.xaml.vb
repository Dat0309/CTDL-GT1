﻿Imports System
Imports System.IO
$if$ ($targetframeworkversion$ == 3.5)
Imports System.Linq
$endif$
Imports System.Windows
Imports System.Windows.Controls
Imports System.Windows.Data
Imports System.Windows.Media
Imports System.Windows.Media.Animation

Partial Public Class $safeitemrootname$
	Inherits UserControl

	Public Sub New()
		InitializeComponent()
		' Insert code required on object creation below this point.
	End Sub

End Class