﻿Imports System
Imports System.Collections.Generic
$if$ ($targetframeworkversion$ == 3.5)
Imports System.Linq
$endif$
Imports System.Text
Imports System.Windows.Data
Imports System.ComponentModel

Public Class $safeitemrootname$
	Implements INotifyPropertyChanged

	Public Sub New()

	End Sub
	
	#Region "INotifyPropertyChanged"
	Private Sub NotifyPropertyChanged(ByRef info As String)
		RaiseEvent PropertyChanged(Me, New PropertyChangedEventArgs(info))
	End Sub

	Public Event PropertyChanged(ByVal sender As Object, ByVal e As System.ComponentModel.PropertyChangedEventArgs) Implements System.ComponentModel.INotifyPropertyChanged.PropertyChanged
	#End Region

End Class