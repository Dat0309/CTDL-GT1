﻿using System;
using System.Collections.Generic;
$if$ ($targetframeworkversion$ == 3.5)
using System.Linq;
$endif$
using System.Text;
using System.Windows.Data;
using System.ComponentModel;

namespace $rootnamespace$
{
	public class $safeitemrootname$ : INotifyPropertyChanged
	{
		public $safeitemrootname$()
		{
			
		}

		#region INotifyPropertyChanged
		public event PropertyChangedEventHandler PropertyChanged;

		private void NotifyPropertyChanged(String info)
		{
			if (PropertyChanged != null)
			{
				PropertyChanged(this, new PropertyChangedEventArgs(info));
			}
		}
		#endregion
	}
}