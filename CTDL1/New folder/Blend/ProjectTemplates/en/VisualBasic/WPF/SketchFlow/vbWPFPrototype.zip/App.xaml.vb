﻿' SketchFlow needs to know which control assembly contains its screens. This is set automatically
' on project creation, but if you change the name of the control assembly manually, you must also
' update it manually here.
<Assembly: Microsoft.Expression.Prototyping.Services.SketchFlowLibraries("$safeassemblyname$.Screens")> 

Class App
	Inherits System.Windows.Application

	' Application-level events, such as Startup, Exit, and DispatcherUnhandledException
	' can be handled in this file.

	Private Sub App_Startup(ByVal o As Object, ByVal e As StartupEventArgs) Handles Me.Startup
		Me.StartupUri = New Uri("pack://application:,,,/Microsoft.Expression.Prototyping.Runtime;Component/WPF/Workspace/PlayerWindow.xaml")
	End Sub
End Class
