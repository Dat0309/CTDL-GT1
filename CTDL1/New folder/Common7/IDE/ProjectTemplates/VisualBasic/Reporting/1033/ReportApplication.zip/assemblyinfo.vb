﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' $WinForm_VB_AssemblyInfo_GeneralInfo$

<Assembly: AssemblyTitle("$projectname$")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("$registeredorganization$")> 
<Assembly: AssemblyProduct("$projectname$")> 
<Assembly: AssemblyCopyright("Copyright © $registeredorganization$ $year$")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'$WinForm_VB_AssemblyInfo_Guid$
<Assembly: Guid("$guid1$")> 

' $WinForm_VB_AssemblyInfo_Version$
'
'      $WinForm_VB_AssemblyInfo_MajorVersion$
'      $WinForm_VB_AssemblyInfo_MinorVersion$ 
'      $WinForm_VB_AssemblyInfo_BuildNumber$
'      $WinForm_VB_AssemblyInfo_Revision$
'
' $WinForm_VB_AssemblyInfo_Version_Final$
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
