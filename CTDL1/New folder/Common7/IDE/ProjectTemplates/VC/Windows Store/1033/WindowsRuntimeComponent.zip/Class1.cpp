﻿// Class1.cpp
#include "pch.h"
#include "Class1.h"

using namespace $safeprojectname$;
using namespace Platform;

Class1::Class1()
{
}
