﻿#pragma once

namespace $safeprojectname$
{
    public ref class WindowsPhoneRuntimeComponent sealed
    {
    public:
        WindowsPhoneRuntimeComponent();
    };
}