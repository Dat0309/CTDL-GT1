﻿// $projectname$.cpp
#include "pch.h"
#include "$projectname$.h"

using namespace $safeprojectname$;
using namespace Platform;

WindowsPhoneRuntimeComponent::WindowsPhoneRuntimeComponent()
{
}
