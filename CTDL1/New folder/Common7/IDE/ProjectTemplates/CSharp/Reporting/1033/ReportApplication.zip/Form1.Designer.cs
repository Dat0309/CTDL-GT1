﻿namespace $safeprojectname$
{
    partial class Form1
    {
        /// <summary>
        /// $WinForm_CSharp_Form1_Designer_components$
        /// </summary>
        private System.ComponentModel.IContainer components;

        /// <summary>
        /// $WinForm_CSharp_Form1_Designer_Dispose$
        /// </summary>
        /// <param name="disposing">$WinForm_CSharp_Form1_Designer_Dispose_disposing$</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region $WinForm_CSharp_Form1_Designer_Region$

        /// <summary>
        /// $WinForm_CSharp_Form1_Designer_InitializeComponent$
        /// </summary>
        private void InitializeComponent()
        {
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.SuspendLayout();
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(682, 386);
            this.reportViewer1.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(682, 386);
            this.Controls.Add(this.reportViewer1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
    }
}

