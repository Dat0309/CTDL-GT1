﻿//
// pch.h
// Header for standard system include files.
//

#pragma once

#include "targetver.h"

// Windows Header Files:
#include <windows.h>
