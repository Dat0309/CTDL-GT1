﻿// $projectname$.cpp : Defines the exported functions for the DLL application.
//

#include "pch.h"
#include "$projectname$.h"
